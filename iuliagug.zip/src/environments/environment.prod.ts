export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyBhc8FMqV-VLRY2lqwIob3glyzyLiCMt6E',
    authDomain: 'iuliagug-323f3.firebaseapp.com',
    databaseURL: 'https://iuliagug-323f3.firebaseio.com',
    projectId: 'iuliagug-323f3',
    storageBucket: 'iuliagug-323f3.appspot.com',
    messagingSenderId: '449069557206',
    appId: '1:449069557206:web:561806f9ca454758467077'
  }
};
