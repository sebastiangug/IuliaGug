// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyBhc8FMqV-VLRY2lqwIob3glyzyLiCMt6E',
    authDomain: 'iuliagug-323f3.firebaseapp.com',
    databaseURL: 'https://iuliagug-323f3.firebaseio.com',
    projectId: 'iuliagug-323f3',
    storageBucket: 'iuliagug-323f3.appspot.com',
    messagingSenderId: '449069557206',
    appId: '1:449069557206:web:561806f9ca454758467077'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
