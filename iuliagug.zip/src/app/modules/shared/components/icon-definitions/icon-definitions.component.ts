import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'icon-definitions',
  templateUrl: './icon-definitions.component.html',
  styleUrls: ['./icon-definitions.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class IconDefinitionsComponent {}
