import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wip-overlay',
  templateUrl: './wip-overlay.component.html',
  styleUrls: ['./wip-overlay.component.scss']
})
export class WipOverlayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
